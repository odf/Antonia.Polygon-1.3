************************************************************
*Product Name: Toni Polygon for Antonia (0.9.121 or higher)
*Copyright February 8 2010
*By: SaintFox and Digital-Lion
*www.german-3d.com
************************************************************

Toni Polygon is a complete texture set for the Antonia figure, made by odf with support of Renderosity forum members. 

You can pick up Antonia here:
http://sites.google.com/site/antoniapolygon/

and read more about her in the Renderosity forums
http://www.renderosity.com/mod/forumpro/showthread.php?thread_id=2753785&page=1

Please check both, the site and the forum for the most recent version of Antonia.

The texture comes with two material systems: A classic version like you may know it from V4 characters and with the VSS material system developed by bagginsbill. 
Please note that each material system requires it's own kind of light set up. To get you started we included some basic light-sets for both, classic and VSS.

This texture set is freestuff and may be used for both, commercial and non-commercial renders.

You are NOT allowed to include the content in this set in your own commercial products or freebies, may it be in parts or in a whole. This set is no merchant resource!

Of course you ARE allowed to use this set as a guide on how to set up Antonia's material shaders.



...and now: Have fun with your brandnew Antonia! Happy rendering!!


SaintFox and Digital-Lion

-------------------------------------------------------------------------------------------------------

Filelist:

\Runtime\Textures\!SaintFox\ToniPolygon\
ToniIBLprobe1.jpg
ToniIBLprobe2.jpg
ToniIBLprobe3.jpg
ToniPARMS_SPEC.jpg
ToniPARMS_tattoo.jpg
ToniPArms.jpg
ToniPArmsBUMP.jpg
ToniPBODY_SPEC.jpg
ToniPBODY_tattoo.jpg
ToniPBody.jpg
ToniPBodyBUMP.jpg
ToniPEyesAmber.jpg
ToniPEyesBUMP.jpg
ToniPEyesBlueGreen.jpg
ToniPEyesBrightGray.jpg
ToniPEyesBrown.jpg
ToniPEyesGray.jpg
ToniPEyesGrayBrown.jpg
ToniPEyesGrayYellow.jpg
ToniPEyesGreenBlue.jpg
ToniPEyesGreenGold.jpg
ToniPHEAD_SPEC.jpg
ToniPHEAD_tattoo.jpg
ToniPHead.jpg
ToniPHeadBUMP.jpg
ToniPHeadBrowsSym.jpg
ToniPHeadBrowsSymBUMP.jpg
ToniPHeadNoBrows.jpg
ToniPHeadNoBrowsBUMP.jpg
ToniPLEGS_SPEC.jpg
ToniPLEGS_tattoo.jpg
ToniPLIPS_SPEC.jpg
ToniPLashFakeTRANS.jpg
ToniPLashIrregTRANS.jpg
ToniPLashTRANS.jpg
ToniPLegs.jpg
ToniPLegsBUMP.jpg
ToniPMouthparts.jpg
ToniPMouthpartsBUMP.jpg

\Runtime\Textures\!SaintFox\Toni\
ToniIBLprobe1.jpg

\Runtime\Libraries\Pose\SF ToniPolygon\
! Classic ! FullTex.png
! Classic ! FullTex.pz2
! Classic FaceBrows1.png
! Classic FaceBrows1.pz2
! Classic FaceBrows2.png
! Classic FaceBrows2.pz2
! Classic FaceNoBrows.png
! Classic FaceNoBrows.pz2
! Classic LipsGlossy.png
! Classic LipsGlossy.pz2
! Classic LipsNatural.png
! Classic LipsNatural.pz2
! Classic SkinNatural.png
! Classic SkinNatural.pz2
! Classic SkinTattoo.png
! Classic SkinTattoo.pz2
! VSS ! FullTex.png
! VSS ! FullTex.pz2
! VSS FaceBrows1.png
! VSS FaceBrows1.pz2
! VSS FaceBrows2.png
! VSS FaceBrows2.pz2
! VSS FaceNoBrows.png
! VSS FaceNoBrows.pz2
! VSS LipsGlossy.png
! VSS LipsGlossy.pz2
! VSS LipsNatural.png
! VSS LipsNatural.pz2
! VSS SkinNatural.png
! VSS SkinNatural.pz2
! VSS SkinTattoo.png
! VSS SkinTattoo.pz2
Eyes BlueBrownDark.png
Eyes BlueBrownDark.pz2
Eyes BlueGreen.png
Eyes BlueGreen.pz2
Eyes BrownAmber.png
Eyes BrownAmber.pz2
Eyes BrownDark.png
Eyes BrownDark.pz2
Eyes GrayBright.png
Eyes GrayBright.pz2
Eyes GrayBrown.png
Eyes GrayBrown.pz2
Eyes GrayDark.png
Eyes GrayDark.pz2
Eyes GreenBlue.png
Eyes GreenBlue.pz2
Eyes GreenGold.png
Eyes GreenGold.pz2
Lashes Default.png
Lashes Default.pz2
Lashes Mascara.png
Lashes Mascara.pz2
Lashes Sparse.png
Lashes Sparse.pz2
Turn Brow Off.png
Turn Brow Off.pz2
Turn Brow On.png
Turn Brow On.pz2
Turn Toecap Off.png
Turn Toecap Off.pz2
Turn Toecap On.png
Turn Toecap On.pz2

\Runtime\Libraries\Light\SF Toni Polygon\
Classic Light 01AO.lt2
Classic Light 01AO.png
Classic Light 01NoAO.lt2
Classic Light 01NoAO.png
Classic Light 02AO.lt2
Classic Light 02AO.png
Classic Light 02NoAO.lt2
Classic Light 02NoAO.png
Classic Light 03AO.lt2
Classic Light 03AO.png
Classic Light 03NoAO.lt2
Classic Light 03NoAO.png
VSS Light 01AO.lt2
VSS Light 01AO.png
VSS Light 01NoAO.lt2
VSS Light 01NoAO.png
VSS Light 02AO.lt2
VSS Light 02AO.png
VSS Light 02NoAO.lt2
VSS Light 02NoAO.png
VSS Light 03AO.lt2
VSS Light 03AO.png
VSS Light 03NoAO.lt2
VSS Light 03NoAO.png